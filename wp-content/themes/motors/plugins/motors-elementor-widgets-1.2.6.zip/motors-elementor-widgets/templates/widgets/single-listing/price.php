<?php
get_template_part( 'partials/single-car/car-price' );


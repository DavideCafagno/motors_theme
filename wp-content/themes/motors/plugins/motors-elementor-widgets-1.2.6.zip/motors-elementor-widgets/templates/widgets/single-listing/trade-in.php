<div class="stm-car_dealer-buttons heading-font">
	<a href="#trade-in" data-toggle="modal" data-target="#trade-in">
		<?php echo esc_html( $tif_btn_label ); ?>
		<i class="stm-moto-icon-trade"></i>
	</a>
</div>

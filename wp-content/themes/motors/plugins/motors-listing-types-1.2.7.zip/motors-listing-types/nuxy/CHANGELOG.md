## 4.1.3
- **FIX:** Security update.

## 4.1.2
- **FIX:** Strings translation issue with non-Latin languages.

## 4.1.1
- **NEW:** RTL compatibility.

## 4.1
- **ADDED:** Message Notification module.
<?php
if(function_exists('woocommerce_catalog_ordering')) {
    woocommerce_catalog_ordering();
}
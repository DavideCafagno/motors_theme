<ul class="butterbean-nav"></ul>
<div class="butterbean-content"></div>
<div class="image-preview">
    <div class="overlay"></div>
</div>